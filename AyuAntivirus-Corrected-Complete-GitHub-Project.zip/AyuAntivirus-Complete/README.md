# Ayu Antivirus

A privacy-first Android security application project designed to build directly on GitHub Actions.

## Build on GitHub
1. Create an empty repository.
2. Upload the **contents of this folder** so `settings.gradle`, `build.gradle`, and `app/` are at repository root.
3. Commit.
4. Open **Actions → Build Ayu Antivirus APK → Run workflow**.
5. Download the `ayu-antivirus-debug-apk` artifact.

No Gradle wrapper is required; the workflow installs Gradle 8.7.

## Included functional modules
- Local SHA-256 hashing and file scanning
- EICAR antivirus test signature detection
- Heuristic content indicators
- Installed-package permission/risk analysis
- APK/file selection through Android Storage Access Framework
- Encrypted AES-GCM quarantine for selected files
- Seven-day local security history
- TXT/CSV/PDF report generation
- Protected WebView browser with Android Safe Browsing where supported
- Package-install/change monitoring
- Download-completion notifications for Android DownloadManager
- Network availability/security-status check
- Smart notification channel
- No account and no advertising SDK

## Android limitations
A normal Android application cannot inspect every other app's private data, gain kernel-level access, silently uninstall arbitrary apps, or guarantee detection of all malware. This project intentionally uses Android's supported APIs and clearly treats heuristic risk findings as indicators rather than proof of malware.

## Test safely
Use the standard EICAR test string/file to verify antivirus-test detection. Do not use real malware on a personal device.
