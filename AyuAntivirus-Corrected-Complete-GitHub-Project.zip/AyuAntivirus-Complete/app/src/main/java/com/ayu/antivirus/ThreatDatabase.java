package com.ayu.antivirus;
import android.content.Context;import java.io.*;import java.util.*;
public final class ThreatDatabase{
 private ThreatDatabase(){}
 public static Set<String> load(Context c){Set<String>s=new HashSet<>();try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getAssets().open("threats.txt")))){String x;while((x=r.readLine())!=null){x=x.trim().toLowerCase(Locale.US);if(x.matches("[0-9a-f]{64}"))s.add(x);}}catch(Exception ignored){}return s;}
}
