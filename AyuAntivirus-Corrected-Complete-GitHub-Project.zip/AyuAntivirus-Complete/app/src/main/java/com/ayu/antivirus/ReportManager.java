package com.ayu.antivirus;
import android.content.*; import android.net.Uri; import java.io.*; import java.nio.charset.StandardCharsets;
public final class ReportManager {
 public static File txt(Context c,String body)throws Exception{File f=new File(c.getExternalFilesDir(null),"ayu-security-report.txt"); try(FileOutputStream o=new FileOutputStream(f)){o.write(body.getBytes(StandardCharsets.UTF_8));} return f;}
 public static File csv(Context c,String body)throws Exception{File f=new File(c.getExternalFilesDir(null),"ayu-security-report.csv"); try(FileOutputStream o=new FileOutputStream(f)){o.write(body.getBytes(StandardCharsets.UTF_8));} return f;}
 public static File pdf(Context c,String body)throws Exception{
  File f=new File(c.getExternalFilesDir(null),"ayu-security-report.pdf"); String safe=body.replace("\\","\\\\").replace("(","\\(").replace(")","\\)").replace("\n"," ");
  String stream="BT /F1 10 Tf 40 760 Td ("+safe.substring(0,Math.min(1800,safe.length()))+") Tj ET";
  String p1="%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Resources<</Font<</F1 4 0 R>>>>/Contents 5 0 R>>endobj\n4 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n5 0 obj<</Length "+stream.length()+">>stream\n"+stream+"\nendstream endobj\nxref\n0 6\n0000000000 65535 f \ntrailer<</Size 6/Root 1 0 R>>\nstartxref\n0\n%%EOF";
  try(FileOutputStream o=new FileOutputStream(f)){o.write(p1.getBytes(StandardCharsets.ISO_8859_1));} return f;
 }
 public static void share(Context c,File f){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,f.getAbsolutePath());c.startActivity(Intent.createChooser(i,"Share report"));}
}
