package com.ayu.antivirus;

import android.content.Context;
import java.io.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.*;

public class QuarantineManager {
    private final Context c; private final File dir; private final byte[] key;
    public QuarantineManager(Context c){ this.c=c; dir=new File(c.getFilesDir(),"quarantine"); dir.mkdirs(); key=getOrCreateKey(); }
    private byte[] getOrCreateKey(){ File f=new File(c.getFilesDir(),"q.key"); try{
        if(f.exists()) return java.nio.file.Files.readAllBytes(f.toPath());
        byte[] k=new byte[32]; new SecureRandom().nextBytes(k); try(FileOutputStream o=new FileOutputStream(f)){o.write(k);} return k;
    }catch(Exception e){ return Arrays.copyOf("AyuAntivirusLocalKey".getBytes(),32); } }
    public File quarantine(File source, String label) throws Exception{
        String safe=System.currentTimeMillis()+"_"+label.replaceAll("[^A-Za-z0-9._-]","_"); File out=new File(dir,safe+".qnt");
        byte[] iv=new byte[12]; new SecureRandom().nextBytes(iv);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,iv));
        try(FileOutputStream fos=new FileOutputStream(out)){ fos.write(iv); try(CipherOutputStream cos=new CipherOutputStream(fos,cipher); FileInputStream in=new FileInputStream(source)){ byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1)cos.write(b,0,n); } }
        return out;
    }
    public File quarantineUri(android.net.Uri uri, String label) throws Exception{
        File temp=new File(c.getCacheDir(),"qtemp_"+System.currentTimeMillis());
        try(InputStream in=c.getContentResolver().openInputStream(uri); FileOutputStream o=new FileOutputStream(temp)){ byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1)o.write(b,0,n); }
        File out=quarantine(temp,label); temp.delete(); return out;
    }

    public List<File> list(){ File[] a=dir.listFiles(); return a==null?Collections.emptyList():Arrays.asList(a); }
    public boolean delete(File f){ return f!=null && (!f.exists() || f.delete()); }
}
