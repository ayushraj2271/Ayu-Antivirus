package com.ayu.antivirus;
import android.content.Context; import java.text.SimpleDateFormat; import java.util.*;
public final class History {
 public static void add(Context c,String event){ String old=c.getSharedPreferences("history",0).getString("items",""); String line=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date())+" — "+event; String[] a=(old.isEmpty()?new String[0]:old.split("\\n")); StringBuilder s=new StringBuilder(line); int count=0; for(String x:a){ if(x.isEmpty())continue; try{String d=x.substring(0,10); Date dt=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(d); long age=System.currentTimeMillis()-dt.getTime(); if(age<=7L*24*60*60*1000 && count<99){s.append('\n').append(x);count++;}}catch(Exception ignored){} } c.getSharedPreferences("history",0).edit().putString("items",s.toString()).apply(); }
 public static String get(Context c){return c.getSharedPreferences("history",0).getString("items","No security events in the last 7 days.");}
}
