package com.ayu.antivirus;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;

public final class ScanEngine {
    public static final int SAFE=0, LOW=1, MEDIUM=2, HIGH=3, CRITICAL=4;
    public static class Result {
        public String name, path, sha256, reason="No known malicious indicators";
        public int severity=SAFE; public long bytes;
        public Result(String n,String p){name=n;path=p;}
        public String level(){ return new String[]{"Safe","Low Risk","Medium Risk","High Risk","Critical"}[severity]; }
    }
    private ScanEngine(){}

    public static Result scanUri(Context c, Uri uri) {
        String name=uri.toString();
        android.database.Cursor cur=null;
        try { cur=c.getContentResolver().query(uri,new String[]{"_display_name","_size"},null,null,null);
            if(cur!=null && cur.moveToFirst()){ int n=cur.getColumnIndex("_display_name"); int s=cur.getColumnIndex("_size"); if(n>=0) name=cur.getString(n); }
        } catch(Exception ignored){} finally{ if(cur!=null)cur.close(); }
        Result r=new Result(name,uri.toString());
        try(InputStream in=c.getContentResolver().openInputStream(uri)){ analyzeStream(c,r,in); }
        catch(Exception e){ r.severity=MEDIUM; r.reason="Could not fully read the selected item: "+e.getClass().getSimpleName(); }
        return r;
    }

    public static Result scanFile(Context c, File f){
        Result r=new Result(f.getName(),f.getAbsolutePath());
        try(InputStream in=new BufferedInputStream(new FileInputStream(f))){ analyzeStream(c,r,in); } catch(Exception e){ r.severity=MEDIUM; r.reason="Read error: "+e.getMessage(); }
        return r;
    }

    private static void analyzeStream(Context c, Result r, InputStream in) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        ByteArrayOutputStream sample=new ByteArrayOutputStream(); byte[] b=new byte[8192]; long total=0; int n;
        while((n=in.read(b))!=-1){ md.update(b,0,n); total+=n; if(sample.size()<1024*1024) sample.write(b,0,n); }
        r.bytes=total; r.sha256=hex(md.digest()); if(c!=null && ThreatDatabase.load(c).contains(r.sha256)){r.severity=CRITICAL; r.reason="Hash matched local Ayu threat database"; return;}
        byte[] s=sample.toByteArray(); String text=new String(s,java.nio.charset.StandardCharsets.ISO_8859_1);
        String lower=text.toLowerCase(Locale.US);
        // EICAR standard test signature. This is intentionally a test, not real malware.
        if(lower.contains("x5o!p%@ap[4\\pzx54(p^)7cc)7}$eicar-standard-antivirus-test-file!$h+h*")){
            r.severity=CRITICAL; r.reason="EICAR antivirus test signature detected"; return;
        }
        String[] suspicious={"powershell","invoke-expression","cmd.exe /c","downloadstring","base64 -d","/data/local/tmp","su -c"};
        int hits=0; for(String x:suspicious) if(lower.contains(x)) hits++;
        String fn=r.name.toLowerCase(Locale.US);
        if(fn.endsWith(".apk") || fn.endsWith(".jar") || fn.endsWith(".dex")) {
            if(hits>=2){r.severity=HIGH;r.reason="Multiple suspicious executable indicators detected";}
            else if(hits==1){r.severity=MEDIUM;r.reason="Suspicious executable indicator detected";}
        } else if(hits>=2){r.severity=MEDIUM;r.reason="Suspicious script/content indicators detected";}
    }

    public static String apkInfo(Context c, Uri uri){
        File temp=new File(c.getCacheDir(),"apkinfo_"+System.currentTimeMillis()+".apk");
        try(InputStream in=c.getContentResolver().openInputStream(uri); FileOutputStream out=new FileOutputStream(temp)){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            android.content.pm.PackageManager pm=c.getPackageManager();
            android.content.pm.PackageInfo pi=pm.getPackageArchiveInfo(temp.getAbsolutePath(), PackageManager.GET_PERMISSIONS|PackageManager.GET_ACTIVITIES|PackageManager.GET_SERVICES|PackageManager.GET_RECEIVERS);
            if(pi==null)return "Android package metadata could not be read from this APK.";
            StringBuilder x=new StringBuilder(); x.append("Package: ").append(pi.packageName).append("\nVersion: ").append(pi.versionName).append("\n");
            if(pi.requestedPermissions!=null)x.append("Permissions: ").append(pi.requestedPermissions.length).append("\n");
            if(pi.activities!=null)x.append("Activities: ").append(pi.activities.length).append("\n");
            if(pi.services!=null)x.append("Services: ").append(pi.services.length).append("\n");
            if(pi.receivers!=null)x.append("Receivers: ").append(pi.receivers.length).append("\n");
            return x.toString();
        }catch(Exception e){return "APK metadata error: "+e.getMessage();} finally {temp.delete();}
    }

    public static String hex(byte[] a){ StringBuilder s=new StringBuilder(); for(byte x:a)s.append(String.format(Locale.US,"%02x",x)); return s.toString(); }

    public static List<PackageInfo> installedApps(Context c){
        PackageManager pm=c.getPackageManager();
        try { return pm.getInstalledPackages(PackageManager.GET_PERMISSIONS|PackageManager.GET_SIGNING_CERTIFICATES); }
        catch(Exception e){ return pm.getInstalledPackages(PackageManager.GET_PERMISSIONS); }
    }

    public static int appRisk(PackageInfo p){
        int score=0; String[] dangerous={"android.permission.READ_SMS","android.permission.RECEIVE_SMS","android.permission.SEND_SMS","android.permission.RECORD_AUDIO","android.permission.CAMERA","android.permission.ACCESS_FINE_LOCATION","android.permission.READ_CONTACTS","android.permission.WRITE_CONTACTS","android.permission.REQUEST_INSTALL_PACKAGES","android.permission.SYSTEM_ALERT_WINDOW","android.permission.BIND_ACCESSIBILITY_SERVICE"};
        if(p.requestedPermissions!=null) for(String q:p.requestedPermissions) for(String d:dangerous) if(q.equals(d)) score++;
        if(score>=5)return HIGH; if(score>=3)return MEDIUM; if(score>=1)return LOW; return SAFE;
    }
}
