package com.ayu.antivirus
import com.ayu.antivirus.domain.*
import org.junit.Assert.assertEquals
import org.junit.Test
class SeverityTest{@Test fun levels(){assertEquals(5,Severity.values().size);assertEquals(Severity.CRITICAL,Severity.valueOf("CRITICAL"))}}
