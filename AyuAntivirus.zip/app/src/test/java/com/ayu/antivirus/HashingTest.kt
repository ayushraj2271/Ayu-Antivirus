package com.ayu.antivirus
import com.ayu.antivirus.core.Hashing
import org.junit.Assert.assertEquals
import org.junit.Test
class HashingTest{@Test fun sha256(){assertEquals("9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",Hashing.sha256("test".toByteArray()))}}
