package com.ayu.antivirus
import com.ayu.antivirus.domain.Confidence
import org.junit.Assert.assertNotEquals
import org.junit.Test
class ThreatModelTest{@Test fun informationalIsNotMalware(){assertNotEquals(Confidence.CONFIRMED_MALICIOUS,Confidence.INFORMATIONAL)}}
