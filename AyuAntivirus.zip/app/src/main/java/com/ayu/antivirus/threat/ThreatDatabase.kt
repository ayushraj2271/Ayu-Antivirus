package com.ayu.antivirus.threat
import android.content.Context
import org.json.JSONObject
import java.io.File

data class ThreatRule(val id:String,val name:String,val type:String,val severity:String,val sha256:String?=null,val indicator:String?=null,val explanation:String="")
class ThreatDatabase(private val context: Context) {
    private val file = File(context.filesDir,"threat-feed.json")
    private var rules: List<ThreatRule> = emptyList()
    init { load() }
    @Synchronized fun load() { rules = if(file.exists()) parse(file.readText()) else defaultRules() }
    fun version(): String = if(file.exists()) runCatching { JSONObject(file.readText()).optString("databaseVersion","1.0-local") }.getOrDefault("1.0-local") else "1.0-local"
    fun rules(): List<ThreatRule> = rules
    fun matchHash(hash:String): ThreatRule? = rules.firstOrNull { it.sha256?.equals(hash,true)==true }
    @Synchronized fun installVerifiedFeed(json:String, expectedSha256:String): Boolean {
        val actual = com.ayu.antivirus.core.Hashing.sha256(json.toByteArray())
        if(!actual.equals(expectedSha256,true)) return false
        val parsed = runCatching { parse(json) }.getOrNull() ?: return false
        if(parsed.isEmpty() && JSONObject(json).optJSONArray("rules")?.length()!=0) return false
        val tmp=File(context.filesDir,"threat-feed.json.tmp"); tmp.writeText(json); if(!tmp.renameTo(file)) return false; rules=parsed; return true
    }
    private fun parse(json:String):List<ThreatRule> { val a=JSONObject(json).optJSONArray("rules") ?: return emptyList(); return buildList { for(i in 0 until a.length()){val o=a.getJSONObject(i); add(ThreatRule(o.optString("id"),o.optString("name"),o.optString("type"),o.optString("severity"),o.optString("sha256").ifBlank{null},o.optString("indicator").ifBlank{null},o.optString("explanation")))} } }
    private fun defaultRules() = listOf(ThreatRule("EICAR-TEST","EICAR Antivirus Test File","TEST","HIGH", "275a021bbfb6483c0a0f1f9c9d5c4b2c7d1c8b3c8e6d5f6c1d8c8c7d5b0d1e0a".lowercase(), null,"Harmless industry-standard antivirus test content."))
}
