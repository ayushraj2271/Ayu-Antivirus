package com.ayu.antivirus.security
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.ayu.antivirus.scheduler.AppInstallWorker
class PackageInstallReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){val p=i.data?.schemeSpecificPart ?: return; WorkManager.getInstance(c).enqueue(OneTimeWorkRequestBuilder<AppInstallWorker>().setInputData(workDataOf("package" to p)).build())}}
