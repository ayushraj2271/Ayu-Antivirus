package com.ayu.antivirus.web
import android.net.Uri
class WebProtection { fun classify(uri:Uri):String { val scheme=uri.scheme?.lowercase(); if(scheme!="https"&&scheme!="http") return "Unsupported scheme"; return "No local malicious-domain match" } }
