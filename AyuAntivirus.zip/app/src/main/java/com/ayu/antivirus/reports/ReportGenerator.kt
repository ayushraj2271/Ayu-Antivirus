package com.ayu.antivirus.reports
import android.content.Context
import com.ayu.antivirus.domain.ScanResult
import java.io.File
class ReportGenerator(private val context:Context){
 fun txt(r:ScanResult):File=File(context.cacheDir,"ayu-report-${System.currentTimeMillis()}.txt").apply{writeText(buildString{appendLine("Ayu Antivirus Report");appendLine("Scan: ${r.type}");appendLine("Scanned: ${r.scanned}");appendLine("Skipped: ${r.skipped}");appendLine("Errors: ${r.errors}");appendLine("Detections: ${r.detections.size}");r.detections.forEach{appendLine("${it.severity} | ${it.confidence} | ${it.name} | ${it.sha256 ?: ""}");it.reasons.forEach{x->appendLine("  - $x")}}})}
 fun csv(r:ScanResult):File=File(context.cacheDir,"ayu-report-${System.currentTimeMillis()}.csv").apply{writeText("severity,confidence,name,sha256,reasons\n"+r.detections.joinToString("\n"){"${it.severity},${it.confidence},${it.name},${it.sha256 ?: ""},\"${it.reasons.joinToString(" | ").replace("\"","\"\"")}\""})}
}
