package com.ayu.antivirus.privacy
import android.content.Context
import android.content.pm.PackageInfo
class PrivacyAnalyzer(private val context:Context){fun sensitivePermissions(p:PackageInfo):List<String>=p.requestedPermissions?.filter{it.contains("CAMERA")||it.contains("MICROPHONE")||it.contains("LOCATION")||it.contains("CONTACTS")||it.contains("SMS")||it.contains("STORAGE")}.orEmpty()}
