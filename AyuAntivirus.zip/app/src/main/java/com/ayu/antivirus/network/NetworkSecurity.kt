package com.ayu.antivirus.network
import android.content.Context
import android.net.ConnectivityManager
class NetworkSecurity(private val context:Context){fun isOnline():Boolean=(context.getSystemService(ConnectivityManager::class.java)?.activeNetwork)!=null}
