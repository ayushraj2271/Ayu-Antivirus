package com.ayu.antivirus.apk
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import com.ayu.antivirus.core.Hashing
import com.ayu.antivirus.domain.*
import com.ayu.antivirus.threat.ThreatDatabase
import java.util.zip.ZipFile
import java.io.File

class ApkAnalyzer(private val context:Context, private val db:ThreatDatabase) {
    fun analyze(uri:Uri): ApkReport {
        val tmp=File(context.cacheDir,"analysis.apk"); context.contentResolver.openInputStream(uri)!!.use { input->tmp.outputStream().use{input.copyTo(it)} }
        val hash=tmp.inputStream().use(Hashing::sha256)
        val pi=context.packageManager.getPackageArchiveInfo(tmp.absolutePath, PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS or PackageManager.GET_SIGNING_CERTIFICATES)
        val permissions=pi?.requestedPermissions?.toList() ?: emptyList()
        val native=ZipFile(tmp).use{z->z.entries().asSequence().filter{it.name.startsWith("lib/") && it.name.endsWith(".so")}.map{it.name}.toList()}
        val signer=pi?.signingInfo?.apkContentsSigners?.firstOrNull()?.let{it.toCharsString()}
        val detections=mutableListOf<Detection>()
        db.matchHash(hash)?.let{detections += Detection(it.name,it.type,Severity.valueOf(it.severity),Confidence.CONFIRMED_MALICIOUS,listOf(it.explanation),hash)}
        val sensitive=permissions.count{it.contains("READ_SMS")||it.contains("RECEIVE_SMS")||it.contains("RECORD_AUDIO")||it.contains("ACCESS_FINE_LOCATION")||it.contains("SYSTEM_ALERT_WINDOW")||it.contains("REQUEST_INSTALL_PACKAGES")}
        if(sensitive>=4) detections += Detection("High-risk permission combination","PERMISSION_RISK",Severity.MEDIUM_RISK,Confidence.SUSPICIOUS,listOf("Multiple sensitive permissions were requested; permissions alone do not prove malware."),hash)
        return ApkReport(pi?.packageName,pi?.versionName,if(android.os.Build.VERSION.SDK_INT>=28)pi?.longVersionCode?.toLong():pi?.versionCode?.toLong(),pi?.applicationInfo?.minSdkVersion,pi?.applicationInfo?.targetSdkVersion,permissions,pi?.activities?.size?:0,pi?.services?.size?:0,pi?.receivers?.size?:0,pi?.providers?.size?:0,native,hash,signer,detections)
    }
}
