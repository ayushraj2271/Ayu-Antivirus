package com.ayu.antivirus.quarantine
import android.content.Context
import java.io.File
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

data class QuarantineItem(val id:String,val originalName:String,val size:Long,val sha256:String,val timestamp:Long)
class QuarantineManager(private val context:Context){
    private val dir=File(context.filesDir,"quarantine").apply{mkdirs()}
    private val alias="ayu_quarantine_key"
    private fun key():SecretKey { val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)}; (ks.getKey(alias,null) as? SecretKey)?.let{return it}; val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore"); kg.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()); return kg.generateKey() }
    fun quarantine(id:String,name:String,data:ByteArray,sha256:String):QuarantineItem { val iv=ByteArray(12).also{SecureRandom().nextBytes(it)}; val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key(),GCMParameterSpec(128,iv)); val out=File(dir,"$id.bin"); out.writeBytes(iv+c.doFinal(data)); return QuarantineItem(id,name,data.size.toLong(),sha256,System.currentTimeMillis()) }
    fun restore(id:String):ByteArray { val b=File(dir,"$id.bin").readBytes(); val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,b.copyOfRange(0,12))); return c.doFinal(b.copyOfRange(12,b.size)) }
    fun delete(id:String)=File(dir,"$id.bin").delete()
}
