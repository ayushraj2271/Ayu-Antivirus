package com.ayu.antivirus

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ayu.antivirus.domain.Detection
import com.ayu.antivirus.notifications.AyuNotifications
import com.ayu.antivirus.scanner.FileScanner
import com.ayu.antivirus.threat.ThreatDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.documentfile.provider.DocumentFile
import com.ayu.antivirus.domain.ScanResult
import com.ayu.antivirus.domain.ScanType

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b); AyuNotifications.createChannels(this); setContent{AyuTheme{AyuApp()}}}
}
@Composable fun AyuTheme(content:@Composable()->Unit){MaterialTheme(content=content)}

@Composable fun AyuApp(vm:com.ayu.antivirus.ui.MainViewModel= viewModel()){
 var tab by remember{mutableIntStateOf(0)}
 Scaffold(bottomBar={NavigationBar{listOf("Home","Scan","Protection","Apps","More").forEachIndexed{i,n->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(if(i==0)Icons.Default.Home else if(i==1)Icons.Default.Security else if(i==2)Icons.Default.Shield else if(i==3)Icons.Default.Apps else Icons.Default.MoreHoriz,n)},label={Text(n)})}}}){p->when(tab){0->Home(p,vm,{tab=1});1->Scan(p,vm);2->Protection(p);3->Apps(p);else->More(p)}}}

@Composable fun Home(p:PaddingValues,vm:com.ayu.antivirus.ui.MainViewModel,onScan:()->Unit){val s by vm.status.collectAsState();val h by vm.history.collectAsState();LazyColumn(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){item{Text("Ayu Antivirus",style=MaterialTheme.typography.headlineMedium);Text("SCAN • PROTECT • SECURE")};item{Card{Column(Modifier.padding(20.dp)){Text(s,style=MaterialTheme.typography.headlineSmall);Text("Security status is derived from local application state.");Spacer(Modifier.height(12.dp));Button(onClick=onScan){Text("SCAN NOW")}}}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("7-day scans",h.size.toString());Stat("Database",vm.databaseVersion())}};item{Text("Protection",style=MaterialTheme.typography.titleLarge)};item{Text("Package-install monitoring uses Android events where available. Core scanning is local and offline-capable.")};item{Text("No account • No ads • No required cloud service")}}}
@Composable fun Stat(a:String,b:String){Card(Modifier.weight(1f)){Column(Modifier.padding(12.dp)){Text(a);Text(b,style=MaterialTheme.typography.titleMedium)}}}

@Composable fun Scan(p:PaddingValues,vm:com.ayu.antivirus.ui.MainViewModel){
 val context=androidx.compose.ui.platform.LocalContext.current; val scope=rememberCoroutineScope(); var detections by remember{mutableStateOf<List<Detection>>(emptyList())}; var busy by remember{mutableStateOf(false)}; var message by remember{mutableStateOf("")}; var scanned by remember{mutableIntStateOf(0)}; var skipped by remember{mutableIntStateOf(0)}
 fun scanUri(uri:Uri){busy=true;message="Scanning…";scope.launch{val d=withContext(Dispatchers.IO){FileScanner(context.contentResolver,ThreatDatabase(context)).scan(uri)};detections=listOfNotNull(d);scanned=1;skipped=0;val r=ScanResult(ScanType.FILE,1,0,0,detections,0);vm.recordScan(r);message=if(d==null)"No local detection match. This is not a guarantee of safety." else "Detection found";busy=false}}
 fun scanTree(uri:Uri){busy=true;message="Scanning accessible files…";scope.launch{val pair=withContext(Dispatchers.IO){val scanner=FileScanner(context.contentResolver,ThreatDatabase(context));var count=0;var skip=0;val ds=mutableListOf<Detection>();fun walk(d:DocumentFile){if(!d.canRead()){skip++;return};if(d.isDirectory){d.listFiles().forEach(::walk)}else{count++;scanner.scan(d.uri)?.let(ds::add)}};val root=DocumentFile.fromTreeUri(context,uri);if(root==null)skip++ else walk(root);Triple(count,skip,ds)};scanned=pair.first;skipped=pair.second;detections=pair.third;vm.recordScan(ScanResult(ScanType.FOLDER,pair.first,pair.second,0,pair.third,0));message="Scan complete: ${pair.first} accessible file(s), ${pair.second} skipped.";busy=false}}
 val filePicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(::scanUri)}
 val treePicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){it?.let{u->context.contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);scanTree(u)}}
 LazyColumn(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Scan Center",style=MaterialTheme.typography.headlineMedium)};item{if(busy)LinearProgressIndicator(Modifier.fillMaxWidth())};item{Button(enabled=!busy,onClick={filePicker.launch(arrayOf("*/*"))}){Text("SELECT FILE • SCAN")}};item{OutlinedButton(enabled=!busy,onClick={treePicker.launch(null)}){Text("SELECT FOLDER • SCAN")}};item{OutlinedButton(enabled=!busy,onClick={filePicker.launch(arrayOf("application/vnd.android.package-archive"))}){Text("SELECT APK • ANALYZE")}};item{Text("A full/user-accessible scan is implemented through Android's folder picker. Only accessible files are counted; denied, missing, or unsupported content is reported as skipped rather than silently treated as clean.")};item{if(message.isNotBlank())Text(message)};item{Text("Scanned: $scanned • Skipped: $skipped • Detections: ${detections.size}")};if(detections.isNotEmpty())item{Card{Column(Modifier.padding(16.dp)){detections.forEach{d->Text("${d.severity} • ${d.confidence}",style=MaterialTheme.typography.titleMedium);Text(d.name);d.reasons.forEach{Text("• $it")}}}}}}
}
@Composable fun Protection(p:PaddingValues){Column(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Protection Center",style=MaterialTheme.typography.headlineMedium);Setting("Real-time app-install event monitoring",true);Setting("Download monitoring",false);Setting("Web protection",false);Setting("Network protection",false);Text("Android limits continuous inspection of other apps' private storage and encrypted traffic. Ayu does not bypass those limits. Optional network/VPN protection requires explicit consent before activation.")}}
@Composable fun Setting(name:String,on:Boolean){Card{Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(name);Text(if(on)"ON" else "OFF")}}}
@Composable fun Apps(p:PaddingValues){val c=androidx.compose.ui.platform.LocalContext.current;Column(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("App Security Center",style=MaterialTheme.typography.headlineMedium);Text("Installed-app metadata can be inspected through PackageManager. Private app data cannot be inspected without Android-authorized access.");Button(onClick={c.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))}){Text("OPEN ANDROID APP MANAGER")}}}
@Composable fun More(p:PaddingValues){LazyColumn(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Security Toolbox",style=MaterialTheme.typography.headlineMedium)};listOf("Privacy Advisor","Tracker Detector","Quarantine","Reports","Security History","Threat Database","Permission Center","Advanced Scan Settings","Network Security","Settings","About").forEach{item{ListItem(headlineContent={Text(it)},modifier=Modifier.fillMaxWidth())}}}}
