package com.ayu.antivirus.scheduler
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
class AppInstallWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p){override suspend fun doWork():Result { return Result.success() /* Metadata-only hook; Android does not expose another app's private files. */ }}
