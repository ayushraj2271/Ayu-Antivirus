package com.ayu.antivirus.notifications
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
object AyuNotifications { fun createChannels(c:Context){val nm=c.getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel("threats","Critical Threats",NotificationManager.IMPORTANCE_HIGH)); nm.createNotificationChannel(NotificationChannel("scans","Scan Results",NotificationManager.IMPORTANCE_DEFAULT)); nm.createNotificationChannel(NotificationChannel("updates","Database Updates",NotificationManager.IMPORTANCE_LOW))} }
