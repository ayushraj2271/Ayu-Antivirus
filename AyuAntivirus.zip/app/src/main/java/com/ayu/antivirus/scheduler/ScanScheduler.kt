package com.ayu.antivirus.scheduler
import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit
class ScanScheduler(private val c:Context){fun scheduleWeekly(){val req=PeriodicWorkRequestBuilder<MaintenanceWorker>(7,TimeUnit.DAYS).setConstraints(Constraints.Builder().setRequiresCharging(true).setRequiresBatteryNotLow(true).build()).build(); WorkManager.getInstance(c).enqueueUniquePeriodicWork("ayu-weekly-scan",ExistingPeriodicWorkPolicy.UPDATE,req)}}
class MaintenanceWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p){override suspend fun doWork():Result=Result.success()}
