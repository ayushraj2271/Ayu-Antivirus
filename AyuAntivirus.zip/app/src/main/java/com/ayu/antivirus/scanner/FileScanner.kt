package com.ayu.antivirus.scanner
import android.content.ContentResolver
import android.net.Uri
import com.ayu.antivirus.core.Hashing
import com.ayu.antivirus.domain.*
import com.ayu.antivirus.threat.ThreatDatabase
import java.io.BufferedInputStream
import java.security.MessageDigest

class FileScanner(private val resolver: ContentResolver, private val db: ThreatDatabase) {
    private val eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H+H*".toByteArray()
    fun scan(uri: Uri): Detection? = runCatching {
        val input=resolver.openInputStream(uri) ?: return null
        input.use { raw ->
            val input=BufferedInputStream(raw,64*1024); val md=MessageDigest.getInstance("SHA-256"); val tail=ByteArray(eicar.size); var tailSize=0; var found=false; val buf=ByteArray(64*1024)
            while(true){val n=input.read(buf); if(n<0) break; if(n==0) continue; md.update(buf,0,n)
                if(!found){val combined=ByteArray(tailSize+n); System.arraycopy(tail,0,combined,0,tailSize); System.arraycopy(buf,0,combined,tailSize,n); for(i in 0..combined.size-eicar.size){var same=true;for(j in eicar.indices)if(combined[i+j]!=eicar[j]){same=false;break};if(same){found=true;break}}; tailSize=minOf(eicar.size-1,combined.size); if(tailSize>0)System.arraycopy(combined,combined.size-tailSize,tail,0,tailSize)}
            }
            val hash=md.digest().joinToString(""){ "%02x".format(it) }
            db.matchHash(hash)?.let{Detection(it.name,it.type,Severity.valueOf(it.severity),Confidence.CONFIRMED_MALICIOUS,listOf(it.explanation),hash)} ?: if(found) Detection("EICAR Test File","TEST",Severity.HIGH_RISK,Confidence.CONFIRMED_MALICIOUS,listOf("The standard harmless EICAR test pattern was found."),hash) else null
        }
    }.getOrNull()
}
