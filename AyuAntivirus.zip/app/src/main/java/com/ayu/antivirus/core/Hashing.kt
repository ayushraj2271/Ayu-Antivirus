package com.ayu.antivirus.core
import java.io.InputStream
import java.security.MessageDigest
object Hashing {
    fun sha256(input: InputStream): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        while (true) { val n=input.read(buffer); if(n<0) break; if(n>0) md.update(buffer,0,n) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
    fun sha256(bytes: ByteArray): String = sha256(bytes.inputStream())
}
