package com.ayu.antivirus.domain

enum class Severity { SAFE, LOW_RISK, MEDIUM_RISK, HIGH_RISK, CRITICAL }
enum class Confidence { CONFIRMED_MALICIOUS, HIGH_CONFIDENCE_SUSPICIOUS, SUSPICIOUS, LIKELY_FALSE_POSITIVE, INFORMATIONAL }
enum class ScanType { QUICK, FULL, DEEP, APPS, APK, FILE, FOLDER, EXTERNAL, DOWNLOAD, CUSTOM, SCHEDULED }
data class Detection(val name:String, val category:String, val severity:Severity, val confidence:Confidence, val reasons:List<String>, val sha256:String? = null)
data class ScanResult(val type:ScanType, val scanned:Int, val skipped:Int, val errors:Int, val detections:List<Detection>, val elapsedMs:Long)
data class ApkReport(val packageName:String?, val versionName:String?, val versionCode:Long?, val minSdk:Int?, val targetSdk:Int?, val permissions:List<String>, val activities:Int, val services:Int, val receivers:Int, val providers:Int, val nativeLibs:List<String>, val sha256:String, val signer:String?, val detections:List<Detection>)
