package com.ayu.antivirus.ui
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ayu.antivirus.data.*
import com.ayu.antivirus.domain.*
import com.ayu.antivirus.threat.ThreatDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
class MainViewModel(app:Application):AndroidViewModel(app){
 private val db=AppDatabase.create(app); private val dao=db.securityDao(); private val threats=ThreatDatabase(app)
 private val _history=MutableStateFlow<List<ScanHistory>>(emptyList()); val history=_history.asStateFlow()
 private val _status=MutableStateFlow("PROTECTED"); val status=_status.asStateFlow()
 init{refresh()}
 fun refresh(){viewModelScope.launch{_history.value=dao.history(System.currentTimeMillis()-7*24*60*60*1000)}}
 fun recordScan(r:ScanResult){viewModelScope.launch{dao.insertScan(ScanHistory(type=r.type.name,timestamp=System.currentTimeMillis(),scanned=r.scanned,skipped=r.skipped,threats=r.detections.size,errors=r.errors));dao.prune(System.currentTimeMillis()-7*24*60*60*1000);_status.value=if(r.detections.any{it.confidence==Confidence.CONFIRMED_MALICIOUS})"ACTION REQUIRED" else "PROTECTED";refresh()}}
 fun databaseVersion()=threats.version()
}
