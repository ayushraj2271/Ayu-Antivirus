package com.ayu.antivirus;

import android.content.*;import android.net.Uri;import java.io.*;import java.security.*;import java.util.*;import javax.crypto.*;import javax.crypto.spec.GCMParameterSpec;import android.security.keystore.KeyGenParameterSpec;import android.security.keystore.KeyProperties;

public final class QuarantineStore{
 private final Context c; private final File dir; private static final String ALIAS="AyuQuarantineKey";
 public QuarantineStore(Context c){this.c=c.getApplicationContext();dir=new File(this.c.getFilesDir(),"quarantine");dir.mkdirs();}
 private SecretKey key()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias(ALIAS)){KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();}
 public File copyInto(Uri u,String display)throws Exception{String safe=(display==null?"item":display).replaceAll("[^A-Za-z0-9._-]","_");File out=new File(dir,System.currentTimeMillis()+"_"+safe+".aq");byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);try(FileOutputStream fos=new FileOutputStream(out)){fos.write(iv);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key(),new GCMParameterSpec(128,iv));try(CipherOutputStream cos=new CipherOutputStream(fos,cipher);InputStream in=c.getContentResolver().openInputStream(u)){if(in==null)throw new IOException("Source unavailable");byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)cos.write(b,0,n);}}return out;}
 public File[] list(){File[] f=dir.listFiles();return f==null?new File[0]:f;}
 public void delete(File f){if(f!=null)f.delete();}
 public String info(File f){return "Encrypted quarantine • "+f.length()+" bytes • "+new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date(f.lastModified()));}
 public void restore(File f,Uri destination)throws Exception{try(FileInputStream fis=new FileInputStream(f)){byte[] iv=new byte[12];if(fis.read(iv)!=12)throw new IOException("Invalid quarantine item");Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));try(CipherInputStream cis=new CipherInputStream(fis,cipher);OutputStream out=c.getContentResolver().openOutputStream(destination)){if(out==null)throw new IOException("Destination unavailable");byte[] b=new byte[65536];int n;while((n=cis.read(b))!=-1)out.write(b,0,n);}}}
}
