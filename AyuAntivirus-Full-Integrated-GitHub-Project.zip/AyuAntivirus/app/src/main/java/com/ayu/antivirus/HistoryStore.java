package com.ayu.antivirus;
import android.content.*;import java.text.*;import java.util.*;
public final class HistoryStore{
 private final SharedPreferences p; public HistoryStore(Context c){p=c.getSharedPreferences("history",Context.MODE_PRIVATE);trim();}
 public synchronized void add(String type,String detail){String old=p.getString("events","");String line=System.currentTimeMillis()+"|"+type+"|"+detail.replace("\n"," ");p.edit().putString("events",line+"\n"+old).apply();trim();}
 public synchronized String get(){trim();StringBuilder b=new StringBuilder();String[] a=p.getString("events","").split("\n");for(String x:a)if(!x.isEmpty()){String[] q=x.split("\\|",3);if(q.length==3)b.append(new SimpleDateFormat("MMM d, HH:mm",Locale.getDefault()).format(new Date(Long.parseLong(q[0])))).append("  ").append(q[1]).append("\n").append(q[2]).append("\n\n");}return b.toString();}
 public void clear(){p.edit().remove("events").apply();}
 private void trim(){long cutoff=System.currentTimeMillis()-7L*24*60*60*1000;StringBuilder b=new StringBuilder();for(String x:p.getString("events","").split("\n"))try{if(!x.isEmpty()&&Long.parseLong(x.split("\\|",2)[0])>=cutoff)b.append(x).append('\n');}catch(Exception ignored){}p.edit().putString("events",b.toString()).apply();}
}
