package com.ayu.antivirus;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class ThreatDatabase {
    public static final class Match { public final String name,severity,category; Match(String n,String s,String c){name=n;severity=s;category=c;} }
    private final Set<String> hashes=new HashSet<>();
    private final Map<String,Match> hashMeta=new HashMap<>();
    private final Set<String> strings=new HashSet<>();
    private final Set<String> domains=new HashSet<>();
    private String version="built-in";
    public ThreatDatabase(Context c){ loadAsset(c); loadLocal(c); }
    private void loadAsset(Context c){ try(InputStream in=c.getAssets().open("threats.json")){load(new String(read(in),StandardCharsets.UTF_8));}catch(Exception ignored){} }
    private void loadLocal(Context c){ File f=new File(c.getFilesDir(),"threats.json"); if(f.exists())try(FileInputStream in=new FileInputStream(f)){load(new String(read(in),StandardCharsets.UTF_8));}catch(Exception ignored){} }
    private void load(String text)throws Exception{ JSONObject o=new JSONObject(text); version=o.optString("version",version); JSONObject hs=o.optJSONObject("hashes"); if(hs!=null){Iterator<String> it=hs.keys();while(it.hasNext()){String h=it.next().toLowerCase(Locale.US);JSONObject m=hs.getJSONObject(h);hashes.add(h);hashMeta.put(h,new Match(m.optString("name","Known threat"),m.optString("severity","High"),m.optString("category","Malware")));}} JSONArray ss=o.optJSONArray("strings");if(ss!=null)for(int i=0;i<ss.length();i++)strings.add(ss.getString(i).toLowerCase(Locale.US)); JSONArray ds=o.optJSONArray("domains");if(ds!=null)for(int i=0;i<ds.length();i++)domains.add(ds.getString(i).toLowerCase(Locale.US)); }
    public Match matchHash(String hash){return hashMeta.get(hash.toLowerCase(Locale.US));}
    public boolean matchString(String s){String x=s.toLowerCase(Locale.US);for(String p:strings)if(x.contains(p))return true;return false;}
    public boolean isBlockedDomain(String host){if(host==null)return false;host=host.toLowerCase(Locale.US);for(String d:domains)if(host.equals(d)||host.endsWith("."+d))return true;return false;}
    public String getVersion(){return version;}
    public void saveUpdated(Context c,String json)throws Exception{JSONObject o=new JSONObject(json);if(!o.has("hashes"))throw new IllegalArgumentException("Invalid feed");File f=new File(c.getFilesDir(),"threats.json");try(FileOutputStream out=new FileOutputStream(f)){out.write(json.getBytes(StandardCharsets.UTF_8));}load(json);}
    private static byte[] read(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return b.toByteArray();}
}
