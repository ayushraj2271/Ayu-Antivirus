package com.ayu.antivirus;
import android.content.*;import android.app.*;import java.util.*;
public final class BootReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){if(!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()))return;AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);Intent x=new Intent(c,ScanScheduleReceiver.class);PendingIntent p=PendingIntent.getBroadcast(c,7001,x,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);long first=System.currentTimeMillis()+6*60*60*1000L;a.setInexactRepeating(AlarmManager.RTC_WAKEUP,first,24*60*60*1000L,p);}
}
