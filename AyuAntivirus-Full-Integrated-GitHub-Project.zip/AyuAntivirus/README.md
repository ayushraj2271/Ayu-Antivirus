# Ayu Antivirus

A privacy-first Android security scanner built with native Android APIs. It is designed around the 30-feature product plan agreed for Ayu Antivirus.

## Included in this single project

- Modern dark security dashboard
- Quick / deep / APK / file / folder / custom scan entry points
- Installed-app analysis
- APK package metadata and permission analysis
- SHA-256 hashing
- Built-in high-confidence test signature (EICAR)
- Local threat database
- Optional HTTPS JSON threat-feed updater
- Pattern/string threat rules
- Heuristic risk levels: Safe / Low / Medium / High / Critical
- Encrypted AES-GCM quarantine using Android Keystore
- Restore/export from quarantine
- 7-day local security history
- TXT / CSV / PDF report export
- Protected in-app browser using WebView Safe Browsing + Ayu local domain list
- Package-install monitoring notifications
- Daily scheduled security reminders
- Network security status check
- Privacy/app-security analysis
- Accessibility-conscious native controls
- No account
- No ads
- No analytics SDK
- No personal-file uploads
- GitHub Actions APK build

## Important Android limitations

A normal Android app cannot inspect every other app's private data, kill arbitrary processes, silently uninstall arbitrary apps, or guarantee detection of every unknown threat. Ayu therefore uses APIs that Android actually exposes and clearly distinguishes heuristic findings from confirmed signatures.

The protected browser protects browsing *inside Ayu*. Device-wide traffic filtering would require Android VPN APIs and additional policy/UX requirements; this project does not silently intercept device traffic.

## Build on GitHub

1. Create a GitHub repository named `AyuAntivirus`.
2. Upload everything in this project to the repository root.
3. Open **Actions**.
4. Run **Build Ayu Antivirus APK**.
5. Download the `ayu-antivirus-debug-apk` artifact.

## Threat feed format

See `app/src/main/assets/threat-feed.example.json`.

You can host a JSON feed on HTTPS (for example, from a repository's raw-file URL) and paste the URL into **Threat Database → HTTPS JSON feed URL**.

## Safety

No real malware samples are included. The bundled EICAR test signature is a standard antivirus test indicator and is intended for safe testing.
